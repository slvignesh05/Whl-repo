def hello():
    return "Hello from pocket_w3shi!"